package pl.devfoundry.testing;

public class Account {

    public String imie;
    public int wiek;

    public Account() {
        this.imie = "Adam";
        this.wiek = 20;
    }

    public void activate() {
        System.out.println("Mam na imie " + imie + "Mam lat " + wiek);
    }

    public boolean isActive() {

        return !imie.isEmpty();
    }
}