package pl.devfoundry.testing;

public class Kawiarnia {
    public String nazwa;
    public int iloscmiejsc;
    public int miejscarezerwowe;
    public int ilemiejsc;

    public Kawiarnia(){
        this.nazwa = "U Jarka";
        this.iloscmiejsc = 60;
        this.miejscarezerwowe = 20;
        this.ilemiejsc = iloscmiejsc + miejscarezerwowe;
    }
    public boolean Kawiarenka(){
        System.out.println("Kawiarnia " + nazwa + "Ma " + ilemiejsc + "miejsc");
        return nazwa.isEmpty();
    }
}
