package pl.devfoundry.testing;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class AccountTest {

    @Test
    void myTest(){
        Account newAccount = new Account();
        assertTrue(newAccount.isActive(),"Check if new account don't have name");
    }

    @Test
    void myTest2(){
        Account newAccount = new Account();
        assertTrue(newAccount.isActive());
        newAccount.activate();
    }

}
