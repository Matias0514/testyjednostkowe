package pl.devfoundry.testing;

import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.assertTrue;

public class KawiarniaTest {
    @Test
    void Test1(){
        Kawiarnia nowaKawiarnia = new Kawiarnia();
        assertTrue(nowaKawiarnia.Kawiarenka());
    }
}
